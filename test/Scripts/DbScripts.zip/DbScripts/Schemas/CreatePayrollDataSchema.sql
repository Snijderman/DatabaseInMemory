IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'PayrollData')
   EXEC sys.sp_executesql N'CREATE SCHEMA [PayrollData]'
GO
